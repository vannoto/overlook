/*function validate (){
    var elt = document.getElementById("textForm");
      
    if (elt.username.value == "")
    {
      window.alert ("Invalid Input: Enter name");
      return false;
    }
      
    if (elt.password.value == "")
    {
      window.alert ("Invalid Input: Enter password");
      return false;
    }
      
    if (elt.repeat.value == "")
    {
      window.alert ("Invalid Input: Enter repeat password");
      return false;
    }
      
    //condition 1: The user name must be between 6 and 10 characters long
    if (elt.username.value.length < 6 | elt.username.value.length > 10) {
        window.alert("Invalid Input: username must be between 6 and 10 characters long"); 
        return false; 
    }
    //condition 2: The user name must contain only letters and digits
    if (elt.username.value.match(/\W/) != null) {
        window.alert ("Invalid Input: username must contain only letters and digits."); 
        console.log(elt.username.value.match(/[^a-zA-Z0-9_]/)); 
        return false; 
    }
    //condition 3: The user name cannot begin with a digit
    if (elt.username.value.match(/^[^0-9]/) == null) {
        window.alert ("Invalid Input: username cannot begin with a digit."); 
        return false; 
    }
      
    //condition 4: The password and the repeat password must match
    if (elt.password.value !== elt.repeat.value) {
        window.alert ("Invalid Input: Password and Repeat Password must be an exact match."); 
        return false; 
    }
      
    //condition 5: The password must be between 6 and 10 characters
    if (elt.password.value.length < 6 | elt.password.value.length > 10) {
        window.alert("Invalid Input: Password must be between 6 and 10 characters long"); 
        return false; 
    }
      
    //condition 6: The password must contain only letters and digits
     if (elt.password.value.match(/\W/) != null) {
        window.alert ("Invalid Input: Password must contain only letters and digits."); 
        return false; 
    }
    
    //condition 7: The password must have at least one lower case letter, at least one upper case letter, and at least one digit
      if(elt.password.value.match(/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]/) == null) {
          window.alert("Invalid Input: Must have one lowercase, one uppercase, and one digit in password"); 
          return false; 
    }
      
    return true;
  }*/

function checkUserBlank (){
    var elt = document.getElementById("textForm");  
    
    //check if username is blank
    if (elt.username.value == ""){
      elt.username.style.borderBottomColor = "red";
      elt.username.style.backgroundColor = "#ffc1c1";
      elt.username.placeholder = "You must enter a username.";
    }
    /*else {
      elt.username.style.backgroundColor = "whitesmoke";
      elt.username.style.borderBottomColor = "darkgray";
      elt.username.placeholder = "Enter a username...";
    }*/
    
    //check if username is between 6 to 10 characters 
    if (elt.username.value.length < 6 | elt.username.value.length > 10) {
        document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'Your username must be between 6 to 10 characters long';
    }
    
    //check if the user name must contain only letters and digits
    if (elt.username.value.match(/\W/) != null) {
        document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'Your username must only contain letters and digits';
    }
}

function checkPassBlank (){
    var elt = document.getElementById("textForm");
    
    if (elt.password.value == ""){
        elt.password.style.borderBottomColor = "red";
        elt.password.style.backgroundColor = "#ffc1c1";
        elt.password.placeholder = "You must enter a password."
    }
    /*else {
        elt.password.style.backgroundColor = "whitesmoke";
        elt.password.style.borderBottomColor = "darkgray";
        elt.password.placeholder = "Enter a password...";
    }*/
    //condition 5: The password must be between 6 and 10 characters
    if (elt.password.value.length < 6 | elt.password.value.length > 10) {
        document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'Your password must be between 6 to 10 characters in length.';
    }
      
    //condition 6: The password must contain only letters and digits
     if (elt.password.value.match(/\W/) != null) {
        document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'Your password must contain only letters and digits'; 
    }
    
    //condition 7: The password must have at least one lower case letter, at least one upper case letter, and at least one digit
      if(elt.password.value.match(/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]/) == null) {
          document.getElementById('message').style.color = 'red';
          document.getElementById('message').innerHTML = 'Your password must contain at least one lowercase letter, one uppercase letter, and one digit';
    }
}

function checkRepeatBlank (){
    var elt = document.getElementById("textForm");
    
    if (elt.repeat.value == ""){
        elt.repeat.style.borderBottomColor = "red";
        elt.repeat.style.backgroundColor = "#ffc1c1";
        elt.repeat.placeholder = "You must repeat your password."
    }
    else {
        elt.repeat.style.backgroundColor = "whitesmoke";
        elt.repeat.style.borderBottomColor = "darkgray";
        elt.repeat.placeholder = "Repeat password...";
    }
}

var checker = function() {
  if (document.getElementById('password').value ===
    document.getElementById('repeat').value) {
    document.getElementById('message').style.color = 'green';
    //document.getElementById('message').innerHTML = 'matching';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'Your password and repeat password must match';
  }
}