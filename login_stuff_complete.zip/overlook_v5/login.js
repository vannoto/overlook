var xhr; 
    if (window.ActiveXObject) { 
        xhr = new ActiveXObject ("Microsoft.XMLHTTP"); 
    } 
    else if (window.XMLHttpRequest) { 
        xhr = new XMLHttpRequest (); 
    } 

function callServer() { 

var un = document.getElementById("user").value; 
var url = "/cs329e-mitra/kosu12/overlook/loginauth.php?username=" + escape(un); 
    
if ((un == null) || (un == "")) return;  

// Create the name-value pairs that will be sent as data 
var params = "userName=user";

// Open a connection to the server 
xhr.open ("POST", url, true); 

// Create the proper headers to send with the request
xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
//xhr.setRequestHeader("Content-length", params.length);
//xhr.setRequestHeader("Connection", "close");

// Setup a function for the server to run when it is done 
xhr.onreadystatechange = updatePage; 

// Send the request 
xhr.send(params); 
} 

function updatePage() { 
    if (xhr.readyState == 4) { 
        if (xhr.status == 200) { 
            var username_used = xhr.responseText; 
            if (username_used !== 'true' || username_used != 'true') {
                window.alert('Username does not exist. Please click the link below to register.'); 
            }
        } 
    } 
} 