<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Overlook</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type= text/css href="./overlook.css">
</head>
     
<body>
    <div class="header"> 
        <div class="register">
            <?php 
                $auth = $_COOKIE['auth']; 
                if ($auth == 'true') {
                    print <<<LOGIN
    <html>
    <body>
    <a href="login.html"> Logout </a>
    </body>
    </html>    
LOGIN;
                }
                else {
                    print <<<LOGIN
    <html>
    <body>
    <a href="login.html"> Log In </a>
    <a href="signup.html"> Sign Up </a>
    </body>
    </html>    
LOGIN;
                }

            ?>
            <!--a href="login.html">Login</a>
            <a href="signup.html">Sign Up</a-->  
        </div>
    </div>
    
    <div class="container">
        <img src="overlook_logo.png" alt="logo" class="logo">
        
        <div class="searchbar">
           <form  action="./results.html" method="get">
               <input type = "text" name = "search" placeholder = "Begin your search..."/>
           </form>
        </div>
    </div>
    

    <div class="blurb">
        <p align="center">Don’t have the time to sift through all of the online thrift shops out there? We aim to make online thrift shopping just a little bit easier with this cross platform search engine.</p> 
    </div>
    
    <form action="./about.html">
        <input type="submit" value="LEARN MORE"/>
    </form>

    <div class="copy"> 
       <p> Copyright Infringement &copy; Notice </p>
       <p>Vanessa Astronoto, Sruthi Kosuru <br>
            Last updated: <script> document.write(new Date().toLocaleDateString()); </script></p>
    </div>
    

</body>
</html>